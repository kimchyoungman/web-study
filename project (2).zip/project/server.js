
$(document).ready(function() {
    $('#inquiry').click(function() {
        $.ajax({
            url: 'data/UnslovedAssignment.json',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                var html = '';
                for (var i = 0; i < data.length; i++) {
                    html += '<p>' + data[i].name + ': ' + data[i].age + '</p>';
                }
                $('.body #result').html(html);
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    });
});
